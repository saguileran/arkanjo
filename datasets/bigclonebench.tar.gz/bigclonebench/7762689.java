public class BigbenchClone{    
    public String getChannelId() {
        return channelId;
    }
}