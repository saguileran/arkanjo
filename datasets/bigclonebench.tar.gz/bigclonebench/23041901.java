public class BigbenchClone{    
    public String getChannelMark(String desc) {
        return (String) m_channels.get(desc);
    }
}