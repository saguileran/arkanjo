public class BigbenchClone{    
    public List<MessageAlertChannel> getChannels() {
        return channels;
    }
}