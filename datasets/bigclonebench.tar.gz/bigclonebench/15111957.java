public class BigbenchClone{    
        
        public ChannelGroup getChannelGroup() {
            return delegate.getChannelGroup();
        }
}