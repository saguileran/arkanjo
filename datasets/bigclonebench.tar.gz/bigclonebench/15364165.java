public class BigbenchClone{    
    public String getChannels() {
        return String.valueOf(getChannelNumber());
    }
}