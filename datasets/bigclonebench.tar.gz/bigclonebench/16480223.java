public class BigbenchClone{    
    public IGenericChannelTemplate getChannelTemplate() throws XAwareException {
        return null;
    }
}