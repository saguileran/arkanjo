public class BigbenchClone{    
    public Channels getChannels() {
        return channels;
    }
}