public class BigbenchClone{    
    protected SocketChannel getChannel() {
        return channel;
    }
}