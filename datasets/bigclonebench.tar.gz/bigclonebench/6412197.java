public class BigbenchClone{    
    public Channel getChannel() {
        return ch;
    }
}