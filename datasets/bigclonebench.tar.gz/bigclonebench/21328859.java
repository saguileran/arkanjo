public class BigbenchClone{    
    public void sayDate(String day, String month, String year) throws Exception {
        TegsoftPBX.sayDate(getChannel(), day, month, year);
    }
}