public class BigbenchClone{    
        public C getChannel() {
            return channel;
        }
}