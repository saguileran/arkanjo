public class BigbenchClone{    
    public InputStream openStream(URL url) throws IOException {
        return url.openStream();
    }
}