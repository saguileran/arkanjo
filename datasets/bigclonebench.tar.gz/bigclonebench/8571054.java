public class BigbenchClone{    
    public int getChannel() {
        return 0;
    }
}