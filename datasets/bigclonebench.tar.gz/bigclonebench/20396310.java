public class BigbenchClone{    
    public NameNormalizer getChannelNormalizer() {
        return channelNormalizer;
    }
}