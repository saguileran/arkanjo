public class BigbenchClone{    
    public int getChannelCount() {
        int count = (outputChannels == BOTH_CHANNELS) ? 2 : 1;
        return count;
    }
}