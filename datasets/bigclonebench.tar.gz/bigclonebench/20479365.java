public class BigbenchClone{    
    public String[] getChannels() {
        return loggernetChannels;
    }
}