public class BigbenchClone{    
    public EClass getChannel() {
        return channelEClass;
    }
}