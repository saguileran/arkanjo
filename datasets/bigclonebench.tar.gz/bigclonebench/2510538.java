public class BigbenchClone{    
    private static String getChannelListURL() {
        return getBaseURL(OP_GET_CHANNEL_LIST);
    }
}