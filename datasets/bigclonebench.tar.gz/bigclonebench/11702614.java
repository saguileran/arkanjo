public class BigbenchClone{    
    public String getChannel() {
        return channel;
    }
}