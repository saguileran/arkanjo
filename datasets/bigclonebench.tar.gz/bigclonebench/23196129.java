public class BigbenchClone{    
    public String getString() {
        return ("read: " + read_dispatcher.getString() + ", write: " + write_dispatcher.getString());
    }
}