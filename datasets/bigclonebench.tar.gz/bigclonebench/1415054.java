public class BigbenchClone{    
    public java.util.Set<com.jeecms.cms.entity.main.Channel> getChannels() {
        return channels;
    }
}