public class BigbenchClone{    
    public Channel leaveAll() {
        getChannel().leaveAll();
        return this;
    }
}