public class BigbenchClone{    
    public synchronized CipherParametersChannel getChannel() {
        return Chan;
    }
}