public class BigbenchClone{    
    public int getChannelNumber() {
        return ((Integer) content.get(FIELD_CHANNEL)).intValue();
    }
}