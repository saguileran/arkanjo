public class BigbenchClone{    
    public void clear() {
        write_index = read_index = 0;
    }
}